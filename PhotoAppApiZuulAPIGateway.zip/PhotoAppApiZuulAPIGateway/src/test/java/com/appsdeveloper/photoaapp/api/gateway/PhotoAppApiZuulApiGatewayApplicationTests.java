package com.appsdeveloper.photoaapp.api.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoAppApiZuulApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
