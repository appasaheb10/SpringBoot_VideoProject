package com.appdeveloper.app.ws.shared;

import java.util.UUID;

public class Utils {

	public String generateId() {
		 return UUID.randomUUID().toString();
	}
	
}
