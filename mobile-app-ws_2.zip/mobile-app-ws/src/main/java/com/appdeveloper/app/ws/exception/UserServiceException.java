package com.appdeveloper.app.ws.exception;

public class UserServiceException extends RuntimeException{

	private static final long serialVersionUID = 312393790952962035L;

	
	
	public UserServiceException(String message) {
		super(message);
	}
	
	
}
