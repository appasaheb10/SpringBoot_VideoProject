package com.appdeveloper.app.ws.userserive;

import com.appdeveloper.app.ws.ui.model.request.UserDetailsRequestModel;
import com.appdeveloper.app.ws.ui.model.response.UserRest;

public interface UserService {

	
	UserRest createUser(UserDetailsRequestModel detailsRequestModel);
}
