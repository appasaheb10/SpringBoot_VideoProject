package com.appdeveloper.app.ws.userserive;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.appdeveloper.app.ws.shared.Utils;
import com.appdeveloper.app.ws.ui.model.request.UserDetailsRequestModel;
import com.appdeveloper.app.ws.ui.model.response.UserRest;

@Service
public class UserServiceImpl implements UserService {
	
	Map<String, UserRest> userMap = new HashMap<String, UserRest>();
	
	Utils utils; 
	
	public UserServiceImpl(){
	}
	
	@Autowired
	public UserServiceImpl(Utils utils){
		this.utils = utils;
	}
	
	
	
	@Override
	public UserRest createUser(UserDetailsRequestModel detailsRequestModel) {
		 UserRest userRest = new UserRest(detailsRequestModel.getFirstName() , 
				 detailsRequestModel.getLastName(), detailsRequestModel.getEmail() ,
				 detailsRequestModel.getPassword());
		 
		 String userId = utils.generateId();
		 userRest.setUserId(userId);
		 
		 userMap.put(userId,userRest);
		 
		 return userRest;
	}

}
