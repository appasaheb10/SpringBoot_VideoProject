package com.dev.mobile.ws.exceptions;

public class UserServiceException extends RuntimeException{

	private static final long serialVersionUID = 312393790952962035L;
}
