package com.dev.mobile.ws.userservice;

import com.dev.mobile.ws.ui.model.request.UserDetailsRequestModel;
import com.dev.mobile.ws.ui.model.response.UserRest;

public interface UserService {
	UserRest createUser(UserDetailsRequestModel userDetails);
}
