package com.dev.mobile.ws.ui.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dev.mobile.ws.exceptions.UserServiceException;
import com.dev.mobile.ws.ui.model.request.UpdateUserDetailsRequestModel;
import com.dev.mobile.ws.ui.model.request.UserDetailsRequestModel;
import com.dev.mobile.ws.ui.model.response.UserRest;

@RestController
@RequestMapping("users2") // http://localhost:8080/users
public class UserController2 {

	
	Map<String, UserRest> usersMap = null;
	
	
	
	@GetMapping()
	public String getUsers(@RequestParam(value="page", required = true) int page, 
			@RequestParam(value="limit", defaultValue = "50") int limit, @RequestParam(value="sort", required = false, defaultValue = "desc") String sort) {
		
		if(true) throw new UserServiceException();
		 // String st = null; int l = 0; l = st.length();
		
		return "get usesr was called with  : " + " page : " + page + " limit = " + limit + " sort :" + sort ;
	}
	
	/*
	 * @GetMapping(path = "/{userid}") public String getUser(@PathVariable String
	 * userid) { return "get user was called with user id : " + userid; }
	 */
	
	
	
	/*
	 * @GetMapping(path = "/{userid}", produces = { MediaType.APPLICATION_XML_VALUE,
	 * MediaType.APPLICATION_JSON_VALUE}) public ResponseEntity<UserRest>
	 * getUser(@PathVariable String userid) { UserRest userRest = new
	 * UserRest("Appasaheb" , "Neelawani" , "abc@gmail.com" , "password");
	 * 
	 * return new ResponseEntity<UserRest>(userRest,HttpStatus.OK); }
	 */
	
	
	
	
	@GetMapping(path = "/{userid}", produces = {
			MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<UserRest> getUser(@PathVariable String userid) {
		//UserRest  userRest = new UserRest("Appasaheb" , "Neelawani" , "abc@gmail.com" , "password");
		
		if(usersMap.containsKey(userid)) {
			return new ResponseEntity<UserRest>(usersMap.get(userid),HttpStatus.OK);
		}else {
			return new ResponseEntity<UserRest>(HttpStatus.NO_CONTENT);
		}
	}
	
	
	/*
	 * @PostMapping public String createUser() { return "create user was called"; }
	 */
	
	@PostMapping(
			consumes = {
			MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE,
			}, 
			produces = {
					MediaType.APPLICATION_XML_VALUE,
					MediaType.APPLICATION_JSON_VALUE,
					})
	public ResponseEntity<UserRest> createUser( @Valid @RequestBody UserDetailsRequestModel userDetails) {
		UserRest userRest = new UserRest(userDetails.getFirstName(), userDetails.getLastName(), userDetails.getEmail(), userDetails.getPassword());
		
		if(usersMap == null) usersMap = new HashMap<String, UserRest>();
		String userId = UUID.randomUUID().toString();
		userRest.setUserId(userId);
		usersMap.put(userId, userRest);
		return new ResponseEntity<UserRest>(userRest, HttpStatus.OK);
	}
	
	
	/*
	 * @PutMapping public String updateUser() { return "put user was called"; }
	 */
	
	
	@PutMapping( path = "/{userid}",  consumes = {
			MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE,
			}, 
			produces = {
					MediaType.APPLICATION_XML_VALUE,
					MediaType.APPLICATION_JSON_VALUE,
					})
	public ResponseEntity<UserRest> updateUser(@PathVariable String userid, @Valid @RequestBody UpdateUserDetailsRequestModel updateUserDetails) {
		if(usersMap.containsKey(userid)) {
			usersMap.get(userid).setFirstName(updateUserDetails.getFirstName());
			usersMap.get(userid).setLastName(updateUserDetails.getLastName());
		}
		
		return new ResponseEntity<UserRest>(usersMap.get(userid), HttpStatus.OK);
	}
	
	
	/*
	 * @DeleteMapping public String deleteUser() { return "delete user was called";
	 * }
	 */
	
	
	@DeleteMapping(path="/{userid}")
	public ResponseEntity<Void> deleteUser(@PathVariable String userid) {
		if(usersMap.containsKey(userid)) {
			usersMap.remove(userid);
			return  ResponseEntity.noContent().build();
		}else {
			return  new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
	}
	
	
	
}
