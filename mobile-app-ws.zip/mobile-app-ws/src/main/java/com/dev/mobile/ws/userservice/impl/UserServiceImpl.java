package com.dev.mobile.ws.userservice.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dev.mobile.ws.shared.Utils;
import com.dev.mobile.ws.ui.model.request.UserDetailsRequestModel;
import com.dev.mobile.ws.ui.model.response.UserRest;
import com.dev.mobile.ws.userservice.UserService;

@Service
public class UserServiceImpl implements UserService{
	Map<String, UserRest> usersMap = null;
	Utils util = null;
	
	public UserServiceImpl() {}
	
	@Autowired   // Constuctor based dependency injection
	public UserServiceImpl(Utils util) {
		this.util = util;
	}
	
	
	@Override
	public UserRest createUser(UserDetailsRequestModel userDetails) {
	UserRest userRest = new UserRest(userDetails.getFirstName(), userDetails.getLastName(), userDetails.getEmail(), userDetails.getPassword());
		
		if(usersMap == null) usersMap = new HashMap<String, UserRest>();
		String userId = util.generateUserId();
		userRest.setUserId(userId);
		usersMap.put(userId, userRest);
		return userRest;
	}
}
